package dto;

public class PayMentDTO {
    private int totalNaverPay;
    private int totalKakaoPay;
    private int totalCard;
    private int totalPc;
    private int totalFood;
    private int totalVou;
    private int totalEtc;

    public int getTotalNaverPay() {
        return totalNaverPay;
    }

    public void setTotalNaverPay(int totalNaverPay) {
        this.totalNaverPay = totalNaverPay;
    }

    public int getTotalKakaoPay() {
        return totalKakaoPay;
    }

    public void setTotalKakaoPay(int totalKakaoPay) {
        this.totalKakaoPay = totalKakaoPay;
    }

    public int getTotalCard() {
        return totalCard;
    }

    public void setTotalCard(int totalCard) {
        this.totalCard = totalCard;
    }

    public int getTotalPc() {
        return totalPc;
    }

    public void setTotalPc(int totalPc) {
        this.totalPc = totalPc;
    }

    public int getTotalFood() {
        return totalFood;
    }

    public void setTotalFood(int totalFood) {
        this.totalFood = totalFood;
    }

    public int getTotalVou() {
        return totalVou;
    }

    public void setTotalVou(int totalVou) {
        this.totalVou = totalVou;
    }

    public int getTotalEtc() {
        return totalEtc;
    }

    public void setTotalEtc(int totalEtc) {
        this.totalEtc = totalEtc;
    }
}
